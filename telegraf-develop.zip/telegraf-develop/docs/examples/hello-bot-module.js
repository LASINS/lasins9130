// Modules documentation: https://telegraf.js.org/#/?id=telegraf-modules
// $> telegraf -t `BOT TOKEN` hello-bot-module.js
module.exports = ({ reply }) => reply('Hello!')
